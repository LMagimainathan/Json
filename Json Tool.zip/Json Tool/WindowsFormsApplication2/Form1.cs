﻿using ExcelDataReader;
using Newtonsoft.Json;
using Syncfusion.XlsIO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace WindowsFormsApplication2
{


    public partial class Form1 : Form
    {
        string filePath = string.Empty;
        string fileExt = string.Empty;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            OpenFileDialog file = new OpenFileDialog(); //open dialog to choose file  
            if (file.ShowDialog() == System.Windows.Forms.DialogResult.OK) //if there is a file choosen by the user  
            {
                filePath = file.FileName; //get the path of the file  
                fileExt = Path.GetExtension(filePath); //get the file extension  

            }
        }



        private DataTable ReadExcel(string filePath, string fileExt)
        {

            throw new NotImplementedException();
        }



        private void txtinifiles_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (fileExt.CompareTo(".xls") == 0 || fileExt.CompareTo(".xlsx") == 0)
            {
                using (var inFile = File.Open(filePath, FileMode.Open, FileAccess.Read))
                {
                    FolderBrowserDialog f1 = new FolderBrowserDialog();
                    f1.ShowDialog();
                    using (var outFile = File.CreateText(f1.SelectedPath + "//Output.json"))
                    {
                        using (var reader = ExcelReaderFactory.CreateReader(inFile, new ExcelReaderConfiguration() { FallbackEncoding = Encoding.GetEncoding(1252) }))
                        using (var writer = new JsonTextWriter(outFile))
                        {
                            writer.Formatting = Formatting.Indented; //I likes it tidy
                            writer.WriteStartArray();
                            int i = 0;
                            reader.Read();
                            reader.Read();//SKIP FIRST ROW, it's TITLES.
                            do
                            {
                                while (reader.Read())
                                {
                                    ++i;
                                    //peek ahead? Bail before we start anything so we don't get an empty object
                                    // var status = reader.GetString(0);
                                    // if (string.IsNullOrEmpty(building)) break;

                                    writer.WriteStartObject();
                                    writer.WritePropertyName("_Id");
                                    writer.WriteValue(i);
                                    writer.WritePropertyName("Building");
                                    writer.WriteStartObject();

                                    writer.WritePropertyName("Value");
                                    writer.WriteValue(Convert.ToInt32(reader.GetValue(1)));

                                    writer.WritePropertyName("RequirementValue");
                                    writer.WriteValue("string");

                                    writer.WritePropertyName("RequirementText");
                                    writer.WriteValue("string");

                                    writer.WritePropertyName("ApprovalFlag");
                                    writer.WriteValue("0");

                                    writer.WritePropertyName("LastModifiedId");
                                    writer.WriteValue("string");
                                    writer.WriteEndObject();

                                    writer.WritePropertyName("Stairs");
                                    writer.WriteStartObject();

                                    writer.WritePropertyName("Value");
                                    writer.WriteValue(reader.GetString(2));

                                    writer.WritePropertyName("Requirementvalue");
                                    writer.WriteValue("string");

                                    writer.WritePropertyName("RequirementText");
                                    writer.WriteValue("string");

                                    writer.WritePropertyName("ApprovalFlag");
                                    writer.WriteValue("0");

                                    writer.WritePropertyName("LastModifiedId");
                                    writer.WriteValue("string");
                                    writer.WriteEndObject();
                                    writer.WritePropertyName("Window");
                                    writer.WriteStartObject();

                                    writer.WritePropertyName("Value");
                                    writer.WriteValue(reader.GetBoolean(3));

                                    writer.WritePropertyName("Requirementvalue");
                                    writer.WriteValue("string");

                                    writer.WritePropertyName("RequirementText");
                                    writer.WriteValue("string");

                                    writer.WritePropertyName("ApprovalFlag");
                                    writer.WriteValue("0");

                                    writer.WritePropertyName("LastModifiedId");
                                    writer.WriteValue("string");
                                    writer.WriteEndObject();
                                    writer.WritePropertyName("Doors");
                                    writer.WriteStartObject();
                                    writer.WritePropertyName("RefX:");
                                    writer.WriteStartObject();
                                    writer.WritePropertyName("X:");
                                    writer.WriteStartObject();

                                    writer.WritePropertyName("Value");
                                    writer.WriteValue(reader.GetValue(4));

                                    writer.WritePropertyName("Requirementvalue");
                                    writer.WriteValue("string");

                                    writer.WritePropertyName("RequirementText");
                                    writer.WriteValue("string");

                                    writer.WritePropertyName("ApprovalFlag");
                                    writer.WriteValue("0");

                                    writer.WritePropertyName("LastModifiedId");
                                    writer.WriteValue("string");

                                    writer.WriteEndObject();
                                    writer.WritePropertyName("Y:");
                                    writer.WriteStartObject();

                                    writer.WritePropertyName("Value");
                                    writer.WriteValue("0");

                                    writer.WritePropertyName("Requirementvalue");
                                    writer.WriteValue("string");

                                    writer.WritePropertyName("RequirementText");
                                    writer.WriteValue("string");

                                    writer.WritePropertyName("ApprovalFlag");
                                    writer.WriteValue("0");

                                    writer.WritePropertyName("LastModifiedId");
                                    writer.WriteValue("string");

                                    writer.WriteEndObject();
                                    writer.WritePropertyName("Z:");
                                    writer.WriteStartObject();

                                    writer.WritePropertyName("value");
                                    writer.WriteValue("0");

                                    writer.WritePropertyName("RequirementValue");
                                    writer.WriteValue("string");

                                    writer.WritePropertyName("RequirementText");
                                    writer.WriteValue("string");

                                    writer.WritePropertyName("ApprovalFlag");
                                    writer.WriteValue("0");

                                    writer.WritePropertyName("LastModifiedId");
                                    writer.WriteValue("string");

                                    writer.WriteEndObject();
                                    writer.WriteEndObject();
                                    writer.WriteEndObject();
                                    writer.WriteEndObject();
                                }
                            } while (reader.NextResult());
                            writer.WriteEndArray();
                        }
                        #region
                        ////Instantiate the spreadsheet creation engine.
                        //using (ExcelEngine excelEngine = new ExcelEngine())
                        //{
                        //    IApplication application = excelEngine.Excel;

                        //    //The workbook is opened.
                        //    FileStream fileStream = new FileStream(filePath, FileMode.Open);

                        //    IWorkbook workbook = application.Workbooks.Open(fileStream, ExcelOpenType.Automatic);
                        //    IWorksheet worksheet = workbook.Worksheets[0];

                        //    //Export worksheet data into CLR Objects

                        //    IList<Customer> customers = worksheet.ExportData<Customer>(1, 1, worksheet.UsedRange.LastRow, workbook.Worksheets[0].UsedRange.LastColumn);

                        //    //open file stream
                        //    FolderBrowserDialog f1 = new FolderBrowserDialog();
                        //    f1.ShowDialog();
                        //    using (StreamWriter nk = File.CreateText(f1.SelectedPath + "//data1.json"))
                        //    {
                        //        JsonSerializer serializer = new JsonSerializer();

                        //        //serialize object directly into file stream
                        //        serializer.Serialize(nk, customers);
                        //    }
                        //    MessageBox.Show("complete");
                        #endregion
                    }

                }
            }
            MessageBox.Show("Process Completed");

        }
    }
}
